# How To Run
This project is also ✨ quirky ✨

Do the `src` and `public` directory thing from last time.

But you also need to install `axios` and `react-router-dom`
